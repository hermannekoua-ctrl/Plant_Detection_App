const String baseUrl = "https://api.openai.com/v1";

const String apiKey =
    "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";
