import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

class ModelService {
  static const List<String> labelMap = [
    'Apple - Apple Scab',
    'Apple - Black Rot',
    'Apple - Cedar Apple Rust',
    'Apple - Healthy',
    'Bell Pepper - Bacterial Spot',
    'Bell Pepper - Healthy',
    'Cherry - Healthy',
    'Cherry - Powdery Mildew',
    'Corn (Maize) - Cercospora Leaf Spot',
    'Corn (Maize) - Common Rust',
    'Corn (Maize) - Healthy',
    'Corn (Maize) - Northern Leaf Blight',
    'Grape - Black Rot',
    'Grape - Esca (Black Measles)',
    'Grape - Healthy',
    'Grape - Leaf Blight',
    'Peach - Bacterial Spot',
    'Peach - Healthy',
    'Potato - Early Blight',
    'Potato - Healthy',
    'Potato - Late Blight',
    'Strawberry - Healthy',
    'Strawberry - Leaf Scorch',
    'Tomato - Bacterial Spot',
    'Tomato - Early Blight',
    'Tomato - Healthy',
    'Tomato - Late Blight',
    'Tomato - Septoria Leaf Spot',
    'Tomato - Yellow Leaf Curl Virus',
  ];
  final String modelAssetPath;
  final int inputSize;
  Interpreter? _interpreter;

  ModelService({
    this.modelAssetPath = 'assets/models/plant_model.tflite',
    this.inputSize = 128,
  });

  bool get isLoaded => _interpreter != null;

  Future<void> loadModel() async {
    if (_interpreter != null) return;
    _interpreter = await Interpreter.fromAsset(modelAssetPath);
    _interpreter!.allocateTensors();
    // Debug: print expected input/output tensor shapes and types
    try {
      final inTensor = _interpreter!.getInputTensor(0);
      final outTensor = _interpreter!.getOutputTensor(0);
      debugPrint('TFLite input shape: ${inTensor.shape}');
      debugPrint('TFLite input type: ${inTensor.type}');
      debugPrint('TFLite output shape: ${outTensor.shape}');
      debugPrint('TFLite output type: ${outTensor.type}');
    } catch (e) {
      debugPrint('Error getting tensor info: $e');
    }
  }

  Future<Map<String, dynamic>> predictDisease(File imageFile) async {
    if (_interpreter == null) {
      await loadModel();
    }

    final imageBytes = await imageFile.readAsBytes();
    final decodedImage = img.decodeImage(imageBytes);
    if (decodedImage == null) {
      throw Exception('Unable to decode selected image.');
    }

    final resizedImage = img.copyResize(
      decodedImage,
      width: inputSize,
      height: inputSize,
    );

    final input = _imageToInput(resizedImage);
    final outputTensor = _interpreter!.getOutputTensor(0);
    final outputShape = outputTensor.shape;
    final numClasses =
        outputShape.length == 2 ? outputShape[1] : outputShape.last;
    final output = List.generate(1, (_) => List.filled(numClasses, 0.0));

    _interpreter!.run(input, output);

    final scores = output[0];

    // Convert raw scores to probabilities with softmax for confidence
    final probs = _softmax(scores);
    final maxIndex = _argMax(probs);
    final confidence = probs[maxIndex];
    final label =
        maxIndex < labelMap.length ? labelMap[maxIndex] : 'Class #$maxIndex';

    return {'label': label, 'confidence': confidence, 'scores': probs};
  }

  List<double> _softmax(List<double> values) {
    final maxVal = values.reduce((a, b) => a > b ? a : b);
    final exps = values.map((v) => math.exp(v - maxVal)).toList();
    final sumExp = exps.fold<double>(0.0, (p, e) => p + e);
    return exps.map((e) => e / sumExp).toList();
  }

  // Return a 4-D input in NHWC format: [1, height, width, channels]
  List<List<List<List<double>>>> _imageToInput(img.Image image) {
    final input = List.generate(
      1,
      (_) => List.generate(
        inputSize,
        (_) => List.generate(inputSize, (_) => List.filled(3, 0.0)),
      ),
    );

    for (var y = 0; y < inputSize; y++) {
      for (var x = 0; x < inputSize; x++) {
        final pixel = image.getPixel(x, y);
        input[0][y][x][0] = pixel.r / 255.0;
        input[0][y][x][1] = pixel.g / 255.0;
        input[0][y][x][2] = pixel.b / 255.0;
      }
    }

    return input;
  }

  int _argMax(List<double> values) {
    var maxIndex = 0;
    var maxValue = values[0];
    for (var i = 1; i < values.length; i++) {
      if (values[i] > maxValue) {
        maxValue = values[i];
        maxIndex = i;
      }
    }
    return maxIndex;
  }

  void close() {
    _interpreter?.close();
    _interpreter = null;
  }
}
